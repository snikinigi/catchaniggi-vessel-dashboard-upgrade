"use client";

import { useEffect, useState } from "react";

type Voyage = {
  id: string; vesselId: string; vesselName: string | null; imo: string | null; mmsi: string | null;
  departurePort: string; departureCountry: string; departureAt: string | null;
  arrivalPort: string; arrivalCountry: string; arrivalAt: string | null;
  matchStatus: "candidate" | "confirmed" | "incomplete" | "rejected"; source: string;
};
type Result = { items: Voyage[]; page: number; pageSize: number; total: number; dataStatus: string; error?: string };
const fmt = (value: string | null) => value ? `${new Date(value).toLocaleString(undefined, { timeZone: "UTC" })} UTC` : "Not recorded";

export default function VoyageTable() {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [from, setFrom] = useState(() => new Date(Date.now() - 90 * 86400000).toISOString().slice(0, 10));
  const [to, setTo] = useState(() => new Date().toISOString().slice(0, 10));
  const [page, setPage] = useState(1);
  const [result, setResult] = useState<Result>({ items: [], page: 1, pageSize: 50, total: 0, dataStatus: "loading" });

  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams({ from, to, page: String(page), pageSize: "50" });
    if (q.trim()) params.set("q", q.trim());
    if (status !== "all") params.set("status", status);
    fetch(`/api/voyages?${params}`, { cache: "no-store", signal: controller.signal })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok && !data.dataStatus) throw new Error(data.error || "Could not load voyages");
        setResult(data as Result);
      })
      .catch((error: unknown) => { if (error instanceof Error && error.name !== "AbortError") setResult({ items: [], page, pageSize: 50, total: 0, dataStatus: "unavailable", error: "Voyage API could not be reached." }); });
    return () => controller.abort();
  }, [q, status, from, to, page]);

  const statusMessage = result.dataStatus === "not_connected" ? "Database not connected. No sample voyages are substituted."
    : result.dataStatus === "connected_no_results" ? "No matching stored records. This is not proof that no ships made the route."
    : result.dataStatus === "provider_error" || result.dataStatus === "unavailable" ? result.error || "Data is unavailable."
    : `${result.total.toLocaleString()} stored voyage record${result.total === 1 ? "" : "s"}`;

  return <section className="panel history-panel">
    <div className="section-head"><div><h2>Voyage history</h2><p className="muted">Rolling 90-day window by default · source-backed records only</p></div><span className="pill">{statusMessage}</span></div>
    <div className="filter-grid">
      <label>Search vessel / IMO / MMSI<input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="e.g. vessel name or IMO" /></label>
      <label>Evidence status<select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}><option value="all">All statuses</option><option value="confirmed">Confirmed</option><option value="candidate">Candidate</option><option value="incomplete">Incomplete</option></select></label>
      <label>Departure from<input type="date" value={from} max={to} onChange={(e) => { setFrom(e.target.value); setPage(1); }} /></label>
      <label>Departure to<input type="date" value={to} min={from} max={new Date().toISOString().slice(0, 10)} onChange={(e) => { setTo(e.target.value); setPage(1); }} /></label>
    </div>
    <div className="table-scroll"><table><thead><tr><th>Vessel</th><th>Route</th><th>Departure (UTC/local browser)</th><th>Arrival (UTC/local browser)</th><th>Evidence</th><th>Source</th></tr></thead>
      <tbody>{result.items.map((v) => <tr key={v.id}>
        <td><a className="vessel-name-link" href={`/vessels/${v.vesselId}`}>{v.vesselName || "Unknown vessel"}</a><div className="muted tiny">{v.imo ? `IMO ${v.imo}` : "IMO not recorded"}{v.mmsi ? ` · MMSI ${v.mmsi}` : ""}</div></td>
        <td>{v.departurePort} <span className="route-arrow">→</span> {v.arrivalPort}</td>
        <td>{fmt(v.departureAt)}</td><td>{fmt(v.arrivalAt)}</td>
        <td><span className={`evidence ${v.matchStatus}`}>{v.matchStatus}</span></td><td>{v.source}</td>
      </tr>)}</tbody></table>
    </div>
    {result.items.length === 0 && <div className="empty">{statusMessage}</div>}
    <div className="pagination"><span className="muted">Page {page} of {Math.max(1, Math.ceil(result.total / result.pageSize))}</span><div><button disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</button><button disabled={page * result.pageSize >= result.total} onClick={() => setPage((p) => p + 1)}>Next</button></div></div>
  </section>;
}
