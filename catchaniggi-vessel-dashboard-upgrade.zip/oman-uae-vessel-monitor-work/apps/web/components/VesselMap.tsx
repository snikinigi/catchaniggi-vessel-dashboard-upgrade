"use client";

import { useEffect, useRef, useState } from "react";
import maplibregl, { Map as MapLibreMap } from "maplibre-gl";

type Position = {
  vesselId: string; name: string | null; imo: string | null; mmsi: string | null;
  vesselType: string | null; observedAt: string; longitude: number; latitude: number;
  speedKnots: number | null; courseDeg: number | null; source: string;
};
type ResponseData = { items: Position[]; dataStatus: string; latestObservedAt?: string | null; error?: string };

const emptyCollection = { type: "FeatureCollection", features: [] } as const;
function featureCollection(items: Position[]) {
  return {
    type: "FeatureCollection" as const,
    features: items.filter((p) => Number.isFinite(Number(p.longitude)) && Number.isFinite(Number(p.latitude)))
      .map((p) => ({ type: "Feature" as const, geometry: { type: "Point" as const, coordinates: [Number(p.longitude), Number(p.latitude)] }, properties: { ...p, observedAt: new Date(p.observedAt).toISOString() } })),
  };
}

export default function VesselMap() {
  const element = useRef<HTMLDivElement>(null);
  const map = useRef<MapLibreMap | null>(null);
  const [data, setData] = useState<ResponseData>({ items: [], dataStatus: "loading" });
  const styleUrl = process.env.NEXT_PUBLIC_MAP_STYLE_URL || "https://demotiles.maplibre.org/style.json";

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const response = await fetch("/api/positions?withinMinutes=60", { cache: "no-store" });
        const json = (await response.json()) as ResponseData;
        if (!cancelled) setData(json);
      } catch {
        if (!cancelled) setData({ items: [], dataStatus: "unavailable", error: "Could not reach the positions API." });
      }
    };
    void load();
    const interval = window.setInterval(load, 60_000);
    return () => { cancelled = true; window.clearInterval(interval); };
  }, []);

  useEffect(() => {
    if (!element.current || map.current) return;
    const instance = new maplibregl.Map({
      container: element.current,
      style: styleUrl,
      center: [56.1, 23.4],
      zoom: 4.7,
      minZoom: 3,
      maxZoom: 15,
      attributionControl: true,
    });
    instance.addControl(new maplibregl.NavigationControl({ visualizePitch: true }), "top-right");
    instance.on("load", () => {
      instance.addSource("vessels", { type: "geojson", data: emptyCollection as never });
      instance.addLayer({
        id: "vessel-points", type: "circle", source: "vessels",
        paint: { "circle-radius": ["interpolate", ["linear"], ["zoom"], 3, 4, 9, 7], "circle-color": "#49d7c8", "circle-stroke-color": "#06111c", "circle-stroke-width": 1.5, "circle-opacity": 0.92 },
      });
      instance.addLayer({
        id: "vessel-labels", type: "symbol", source: "vessels", minzoom: 6,
        layout: { "text-field": ["coalesce", ["get", "name"], ["get", "mmsi"]], "text-size": 11, "text-offset": [0, 1.25], "text-anchor": "top", "text-allow-overlap": false },
        paint: { "text-color": "#eaf5ff", "text-halo-color": "#07121e", "text-halo-width": 1.5 },
      });
      instance.on("click", "vessel-points", (event) => {
        const feature = event.features?.[0];
        if (!feature || feature.geometry.type !== "Point") return;
        const props = feature.properties || {};
        const coords = feature.geometry.coordinates as [number, number];
        const popup = document.createElement("div");
        popup.className = "vessel-popup";
        const title = document.createElement("strong"); title.textContent = String(props.name || "Unknown vessel"); popup.appendChild(title);
        const rows = [props.vesselType && `Type: ${props.vesselType}`, props.imo && `IMO: ${props.imo}`, props.mmsi && `MMSI: ${props.mmsi}`, `Observed: ${new Date(String(props.observedAt)).toLocaleString()}`, props.speedKnots != null && `Speed: ${props.speedKnots} kn`, props.courseDeg != null && `Course: ${props.courseDeg}°`, `Source: ${props.source}`].filter(Boolean);
        const details = document.createElement("div"); details.textContent = rows.join(" · "); popup.appendChild(details);
        const link = document.createElement("a"); link.href = `/vessels/${String(props.vesselId || "")}`; link.textContent = "Open vessel profile →"; popup.appendChild(link);
        new maplibregl.Popup({ maxWidth: "300px" }).setLngLat(coords).setDOMContent(popup).addTo(instance);
      });
      instance.on("mouseenter", "vessel-points", () => { instance.getCanvas().style.cursor = "pointer"; });
      instance.on("mouseleave", "vessel-points", () => { instance.getCanvas().style.cursor = ""; });
    });
    map.current = instance;
    return () => { instance.remove(); map.current = null; };
  }, [styleUrl]);

  useEffect(() => {
    const instance = map.current;
    if (!instance) return;
    const update = () => {
      const source = instance.getSource("vessels") as { setData: (data: never) => void } | undefined;
      source?.setData(featureCollection(data.items) as never);
    };
    if (instance.isStyleLoaded() && instance.getSource("vessels")) update(); else instance.once("load", update);
  }, [data]);

  const statusText = data.dataStatus === "ready"
    ? `${data.items.length} real position${data.items.length === 1 ? "" : "s"} observed in the last hour`
    : data.dataStatus === "not_connected" ? "Database not connected — no vessel markers shown"
    : data.dataStatus === "connected_no_recent_positions" ? "No positions recorded in the last hour — this does not mean there are no vessels"
    : data.error || "Waiting for position data";

  return <div className="map-frame">
    <div className="map-status"><span className={data.dataStatus === "ready" ? "status-dot live" : "status-dot"} />{statusText}</div>
    <div ref={element} className="map-canvas" aria-label="Map of the Gulf of Oman and the United Arab Emirates" />
    <div className="map-footnote">Markers are shown only when backed by stored AIS position records. The map does not invent locations.</div>
  </div>;
}
