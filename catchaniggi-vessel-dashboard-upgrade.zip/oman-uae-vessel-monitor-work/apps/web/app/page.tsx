import { Pool } from "pg";
import VoyageTable from "../components/VoyageTable";
import VesselMap from "../components/VesselMap";

export const dynamic = "force-dynamic";

async function getStatus() {
  if (!process.env.DATABASE_URL) return { database: "not configured", voyages: null as number | null, recentPositions: null as number | null };
  const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 1 });
  try {
    const result = await pool.query(`SELECT
      (SELECT COUNT(*)::int FROM voyages WHERE departure_at >= NOW() - INTERVAL '90 days' AND match_status <> 'rejected') AS voyages,
      (SELECT COUNT(DISTINCT vessel_id)::int FROM vessel_positions WHERE observed_at >= NOW() - INTERVAL '60 minutes') AS positions`);
    return { database: "connected", voyages: result.rows[0].voyages as number, recentPositions: result.rows[0].positions as number };
  } catch {
    return { database: "unavailable", voyages: null, recentPositions: null };
  } finally { await pool.end(); }
}

export default async function Home() {
  const status = await getStatus();
  const providerConfigured = Boolean(process.env.AIS_API_KEY || process.env.AISSTREAM_API_KEY);
  return <main className="shell">
    <header className="topbar">
      <div className="brand"><div className="mark">GV</div><div><h1>Gulf Vessel Intelligence</h1><div className="eyebrow">OMAN <span>→</span> UNITED ARAB EMIRATES</div></div></div>
      <div className="header-right"><span className="pill">Historical coverage · rolling 90 days</span><span className="pill subtle">No synthetic vessel records</span></div>
    </header>

    <section className="cards">
      <div className="panel metric"><div className="metric-label">Stored voyages · 90 days</div><div className="stat">{status.voyages === null ? "—" : status.voyages.toLocaleString()}</div><div className="muted tiny">{status.voyages === null ? "Database unavailable or not configured" : status.voyages === 0 ? "No stored matches; not proof of zero traffic" : "Non-rejected voyage records"}</div></div>
      <div className="panel metric"><div className="metric-label">Recent AIS positions</div><div className="stat">{status.recentPositions === null ? "—" : status.recentPositions.toLocaleString()}</div><div className="muted tiny">Unique vessels observed in the last 60 minutes</div></div>
      <div className="panel metric"><div className="metric-label">Data connection</div><div className="stat status-stat">{status.database === "connected" && providerConfigured ? "Configured*" : status.database === "connected" ? "Provider missing" : status.database}</div><div className="muted tiny">*Credentials configured does not prove live access or coverage</div></div>
    </section>

    <section className="panel map-panel"><div className="section-head"><div><h2>Live AIS map</h2><p className="muted">Gulf of Oman · Strait of Hormuz · UAE coast</p></div><span className="live-label"><i /> POSITION FEED</span></div><VesselMap /></section>
    <VoyageTable />
    <footer className="footer"><span>Gulf Vessel Intelligence</span><span>Port-call evidence and AIS positions are distinct data products. Confirmed status requires matching arrival and departure evidence.</span><a href="/api/health" target="_blank" rel="noreferrer">System health ↗</a></footer>
  </main>;
}
