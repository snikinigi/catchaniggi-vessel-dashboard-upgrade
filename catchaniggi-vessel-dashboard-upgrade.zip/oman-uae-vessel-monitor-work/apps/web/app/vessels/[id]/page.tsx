"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

type Payload = {
  dataStatus?: string; error?: string;
  vessel: null | { id: string; name: string | null; imo: string | null; mmsi: string | null; vesselType: string | null; flag: string | null; lengthM: number | null; widthM: number | null; lastPositionAt: string | null; lastProviderSyncAt: string | null };
  voyages: Array<{ id: string; departurePort: string; arrivalPort: string; departureAt: string | null; arrivalAt: string | null; matchStatus: string; matchMethod: string; source: string }>;
  recentPositions: Array<{ observedAt: string; longitude: number; latitude: number; speedKnots: number | null; courseDeg: number | null; source: string }>;
};
const fmt = (value: string | null) => value ? `${new Date(value).toLocaleString(undefined, { timeZone: "UTC" })} UTC` : "Not recorded";

export default function VesselDetailPage() {
  const params = useParams<{ id: string }>();
  const [payload, setPayload] = useState<Payload | null>(null);
  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/vessels/${params.id}`, { cache: "no-store", signal: controller.signal }).then((r) => r.json()).then(setPayload).catch(() => setPayload({ error: "Could not load vessel details", vessel: null, voyages: [], recentPositions: [] }));
    return () => controller.abort();
  }, [params.id]);

  if (!payload) return <main className="shell"><p className="muted">Loading vessel details…</p></main>;
  if (!payload.vessel) return <main className="shell"><a className="back-link" href="/">← Back to dashboard</a><section className="panel"><h1>Vessel details unavailable</h1><p className="muted">{payload.error || (payload.dataStatus === "not_connected" ? "The database is not connected." : "No vessel record was found.")}</p></section></main>;
  const v = payload.vessel;
  return <main className="shell detail-shell">
    <a className="back-link" href="/">← Back to dashboard</a>
    <header className="detail-header"><div><div className="eyebrow">VESSEL PROFILE</div><h1>{v.name || "Unknown vessel"}</h1><p className="muted">{v.vesselType || "Type not recorded"} · {v.flag || "Flag not recorded"}</p></div><span className="pill">Source-backed profile</span></header>
    <section className="cards detail-cards">
      <div className="panel"><div className="metric-label">IMO</div><div className="detail-value">{v.imo || "Not recorded"}</div></div>
      <div className="panel"><div className="metric-label">MMSI</div><div className="detail-value">{v.mmsi || "Not recorded"}</div></div>
      <div className="panel"><div className="metric-label">Dimensions</div><div className="detail-value">{v.lengthM || "—"} × {v.widthM || "—"} m</div></div>
      <div className="panel"><div className="metric-label">Last position timestamp</div><div className="detail-value small-value">{fmt(v.lastPositionAt)}</div></div>
    </section>
    <section className="panel history-panel"><h2>Voyage history · last 90 days</h2><div className="table-scroll"><table><thead><tr><th>Route</th><th>Departure</th><th>Arrival</th><th>Evidence</th><th>Match method</th><th>Source</th></tr></thead><tbody>{payload.voyages.map((x) => <tr key={x.id}><td>{x.departurePort} → {x.arrivalPort}</td><td>{fmt(x.departureAt)}</td><td>{fmt(x.arrivalAt)}</td><td><span className={`evidence ${x.matchStatus}`}>{x.matchStatus}</span></td><td>{x.matchMethod}</td><td>{x.source}</td></tr>)}</tbody></table></div>{!payload.voyages.length && <div className="empty">No stored voyages for this vessel in the last 90 days.</div>}</section>
    <section className="panel history-panel"><h2>Recent position observations · last 24 hours</h2><div className="table-scroll"><table><thead><tr><th>Observed at</th><th>Latitude</th><th>Longitude</th><th>Speed</th><th>Course</th><th>Source</th></tr></thead><tbody>{payload.recentPositions.map((p, i) => <tr key={`${p.observedAt}-${i}`}><td>{fmt(p.observedAt)}</td><td>{Number(p.latitude).toFixed(5)}</td><td>{Number(p.longitude).toFixed(5)}</td><td>{p.speedKnots == null ? "—" : `${p.speedKnots} kn`}</td><td>{p.courseDeg == null ? "—" : `${p.courseDeg}°`}</td><td>{p.source}</td></tr>)}</tbody></table></div>{!payload.recentPositions.length && <div className="empty">No position observations are stored for the last 24 hours.</div>}</section>
  </main>;
}
