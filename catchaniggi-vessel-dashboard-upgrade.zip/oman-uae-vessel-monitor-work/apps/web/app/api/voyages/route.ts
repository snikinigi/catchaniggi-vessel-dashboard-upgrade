import { NextRequest, NextResponse } from "next/server";
import { Pool } from "pg";
import { z } from "zod";

export const dynamic = "force-dynamic";
const querySchema = z.object({
  from: z.string().date().optional(),
  to: z.string().date().optional(),
  departurePortId: z.string().uuid().optional(),
  arrivalPortId: z.string().uuid().optional(),
  vesselType: z.string().optional(),
  status: z.enum(["candidate", "confirmed", "incomplete", "rejected"]).optional(),
  q: z.string().max(100).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(50)
});

export async function GET(request: NextRequest) {
  const parsed = querySchema.safeParse(Object.fromEntries(request.nextUrl.searchParams.entries()));
  if (!parsed.success) return NextResponse.json({ error: "Invalid query parameters", details: parsed.error.flatten() }, { status: 400 });
  if (!process.env.DATABASE_URL) {
    return NextResponse.json({ items: [], page: parsed.data.page, pageSize: parsed.data.pageSize, total: 0, dataStatus: "not_connected" });
  }

  const q = parsed.data;
  const from = q.from ? `${q.from}T00:00:00Z` : new Date(Date.now() - 90 * 86400000).toISOString();
  const toExclusive = q.to
    ? new Date(new Date(`${q.to}T00:00:00Z`).getTime() + 86400000).toISOString()
    : new Date(Date.now() + 86400000).toISOString();

  const values: unknown[] = [from, toExclusive];
  const conditions = ["v.departure_at >= $1::timestamptz", "v.departure_at < $2::timestamptz"];
  const add = (sql: string, value: unknown) => { values.push(value); conditions.push(sql.replace("?", `$${values.length}`)); };
  if (q.departurePortId) add("v.departure_port_id = ?::uuid", q.departurePortId);
  if (q.arrivalPortId) add("v.arrival_port_id = ?::uuid", q.arrivalPortId);
  if (q.status) add("v.match_status = ?", q.status);
  if (q.vesselType && q.vesselType !== "all") add("LOWER(COALESCE(s.vessel_type, '')) = LOWER(?)", q.vesselType);
  if (q.q) {
    values.push(`%${q.q}%`);
    const p = `$${values.length}`;
    conditions.push(`(s.name ILIKE ${p} OR s.imo ILIKE ${p} OR s.mmsi ILIKE ${p})`);
  }
  const where = conditions.join(" AND ");
  const offset = (q.page - 1) * q.pageSize;
  const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 2 });
  try {
    const count = await pool.query(`SELECT COUNT(*)::int AS total FROM voyages v JOIN vessels s ON s.id=v.vessel_id WHERE ${where}`, values);
    const dataValues = [...values, q.pageSize, offset];
    const result = await pool.query(
      `SELECT v.id, s.id AS "vesselId", s.name AS "vesselName", s.imo, s.mmsi, dp.name AS "departurePort",
              dp.country_code AS "departureCountry", v.departure_at AS "departureAt",
              ap.name AS "arrivalPort", ap.country_code AS "arrivalCountry",
              v.arrival_at AS "arrivalAt", v.match_status AS "matchStatus", v.source
       FROM voyages v
       JOIN vessels s ON s.id=v.vessel_id
       JOIN ports dp ON dp.id=v.departure_port_id
       JOIN ports ap ON ap.id=v.arrival_port_id
       WHERE ${where}
       ORDER BY v.departure_at DESC NULLS LAST
       LIMIT $${values.length + 1} OFFSET $${values.length + 2}`,
      dataValues
    );
    return NextResponse.json({
      items: result.rows, page: q.page, pageSize: q.pageSize, total: count.rows[0].total,
      dataStatus: result.rows.length ? "ready" : "connected_no_results",
      window: { from, toExclusive }
    });
  } catch {
    return NextResponse.json({ items: [], page: q.page, pageSize: q.pageSize, total: 0, dataStatus: "provider_error", error: "Voyage query failed; check migrations and database logs." }, { status: 503 });
  } finally {
    await pool.end();
  }
}
