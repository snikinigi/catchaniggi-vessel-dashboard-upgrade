import { NextResponse } from "next/server";
import { Pool } from "pg";

export const dynamic = "force-dynamic";

export async function GET() {
  const historicalProviderConfigured = Boolean(process.env.AIS_API_KEY);
  const liveProviderConfigured = Boolean(process.env.AISSTREAM_API_KEY);
  const providerConfigured = historicalProviderConfigured || liveProviderConfigured;
  if (!process.env.DATABASE_URL) {
    return NextResponse.json({ status: "not_ready", database: "not_configured", provider: providerConfigured ? "configured_unverified" : "not_connected", historicalProvider: historicalProviderConfigured ? "configured_unverified" : "not_connected", liveProvider: liveProviderConfigured ? "configured_unverified" : "not_connected" }, { status: 503 });
  }
  const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 1 });
  try {
    await pool.query("SELECT 1");
    return NextResponse.json({ status: providerConfigured ? "configured_unverified" : "not_ready", database: "connected", provider: providerConfigured ? "configured_unverified" : "not_connected", historicalProvider: historicalProviderConfigured ? "configured_unverified" : "not_connected", liveProvider: liveProviderConfigured ? "configured_unverified" : "not_connected", note: "Provider credentials are not validated by this health check." });
  } catch {
    return NextResponse.json({ status: "not_ready", database: "unavailable", provider: providerConfigured ? "configured_unverified" : "not_connected", historicalProvider: historicalProviderConfigured ? "configured_unverified" : "not_connected", liveProvider: liveProviderConfigured ? "configured_unverified" : "not_connected" }, { status: 503 });
  } finally {
    await pool.end();
  }
}
