import { NextRequest, NextResponse } from "next/server";
import { Pool } from "pg";
import { z } from "zod";

export const dynamic = "force-dynamic";
const schema = z.object({
  withinMinutes: z.coerce.number().int().min(1).max(1440).default(60),
  q: z.string().max(100).optional(),
  vesselType: z.string().max(50).optional(),
});

export async function GET(request: NextRequest) {
  const parsed = schema.safeParse(Object.fromEntries(request.nextUrl.searchParams.entries()));
  if (!parsed.success) return NextResponse.json({ error: "Invalid query parameters" }, { status: 400 });
  if (!process.env.DATABASE_URL) {
    return NextResponse.json({ items: [], dataStatus: "not_connected", withinMinutes: parsed.data.withinMinutes });
  }

  const { withinMinutes, q, vesselType } = parsed.data;
  const values: unknown[] = [withinMinutes];
  const filters = ["p.observed_at >= NOW() - ($1::text || ' minutes')::interval"];
  if (q) { values.push(`%${q}%`); filters.push(`(s.name ILIKE $${values.length} OR s.imo ILIKE $${values.length} OR s.mmsi ILIKE $${values.length})`); }
  if (vesselType && vesselType !== "all") { values.push(vesselType); filters.push(`s.vessel_type ILIKE $${values.length}`); }

  const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 1 });
  try {
    const result = await pool.query(
      `SELECT DISTINCT ON (s.id)
         s.id AS "vesselId", s.name, s.imo, s.mmsi, s.vessel_type AS "vesselType",
         p.observed_at AS "observedAt", ST_X(p.position::geometry) AS longitude,
         ST_Y(p.position::geometry) AS latitude, p.speed_knots AS "speedKnots",
         p.course_deg AS "courseDeg", p.source
       FROM vessel_positions p JOIN vessels s ON s.id=p.vessel_id
       WHERE ${filters.join(" AND ")}
       ORDER BY s.id, p.observed_at DESC`, values);
    const latest = result.rows.reduce((max, row) => Math.max(max, new Date(row.observedAt).getTime()), 0);
    return NextResponse.json({ items: result.rows, dataStatus: result.rows.length ? "ready" : "connected_no_recent_positions", withinMinutes, latestObservedAt: latest ? new Date(latest).toISOString() : null });
  } catch {
    return NextResponse.json({ items: [], dataStatus: "query_error", error: "Position query failed; verify the database migration and logs." }, { status: 503 });
  } finally { await pool.end(); }
}
