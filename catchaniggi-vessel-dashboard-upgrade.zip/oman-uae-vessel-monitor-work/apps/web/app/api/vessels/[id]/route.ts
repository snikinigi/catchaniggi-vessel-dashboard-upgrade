import { NextResponse } from "next/server";
import { Pool } from "pg";
import { z } from "zod";

export const dynamic = "force-dynamic";
const idSchema = z.string().uuid();

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!idSchema.safeParse(id).success) return NextResponse.json({ error: "Invalid vessel id" }, { status: 400 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ dataStatus: "not_connected", vessel: null, voyages: [] });
  const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 1 });
  try {
    const vessel = await pool.query(`SELECT id, name, imo, mmsi, vessel_type AS "vesselType", flag_code AS flag,
      length_m AS "lengthM", width_m AS "widthM", last_position_at AS "lastPositionAt", last_provider_sync_at AS "lastProviderSyncAt"
      FROM vessels WHERE id=$1`, [id]);
    if (!vessel.rowCount) return NextResponse.json({ error: "Vessel not found" }, { status: 404 });
    const voyages = await pool.query(`SELECT v.id, dp.name AS "departurePort", ap.name AS "arrivalPort",
      v.departure_at AS "departureAt", v.arrival_at AS "arrivalAt", v.match_status AS "matchStatus", v.match_method AS "matchMethod", v.source
      FROM voyages v JOIN ports dp ON dp.id=v.departure_port_id JOIN ports ap ON ap.id=v.arrival_port_id
      WHERE v.vessel_id=$1 AND v.departure_at >= NOW() - INTERVAL '90 days' AND v.match_status <> 'rejected'
      ORDER BY v.departure_at DESC NULLS LAST LIMIT 100`, [id]);
    const positions = await pool.query(`SELECT observed_at AS "observedAt", ST_X(position::geometry) AS longitude,
      ST_Y(position::geometry) AS latitude, speed_knots AS "speedKnots", course_deg AS "courseDeg", source
      FROM vessel_positions WHERE vessel_id=$1 AND observed_at >= NOW() - INTERVAL '24 hours'
      ORDER BY observed_at DESC LIMIT 200`, [id]);
    return NextResponse.json({ dataStatus: "ready", vessel: vessel.rows[0], voyages: voyages.rows, recentPositions: positions.rows });
  } catch {
    return NextResponse.json({ error: "Vessel detail query failed" }, { status: 503 });
  } finally { await pool.end(); }
}
