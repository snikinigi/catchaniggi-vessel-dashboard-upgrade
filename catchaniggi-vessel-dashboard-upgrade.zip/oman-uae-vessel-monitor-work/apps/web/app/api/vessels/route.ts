import { NextRequest, NextResponse } from "next/server";
import { Pool } from "pg";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  if (!process.env.DATABASE_URL) return NextResponse.json({ items: [], dataStatus: "not_connected" });
  const q = (request.nextUrl.searchParams.get("q") || "").slice(0, 100);
  const page = Math.max(1, Number(request.nextUrl.searchParams.get("page") || 1));
  const pageSize = Math.min(100, Math.max(1, Number(request.nextUrl.searchParams.get("pageSize") || 50)));
  const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 1 });
  try {
    const values = [`%${q}%`, pageSize, (page - 1) * pageSize];
    const result = await pool.query(
      `SELECT id, name, imo, mmsi, vessel_type AS "vesselType", flag_code AS "flagCode", last_position_at AS "lastPositionAt"
       FROM vessels WHERE ($1 = '%%' OR name ILIKE $1 OR imo ILIKE $1 OR mmsi ILIKE $1)
       ORDER BY name NULLS LAST LIMIT $2 OFFSET $3`, values
    );
    return NextResponse.json({ items: result.rows, page, pageSize, dataStatus: result.rows.length ? "ready" : "connected_no_results" });
  } catch {
    return NextResponse.json({ items: [], dataStatus: "provider_error" }, { status: 503 });
  } finally {
    await pool.end();
  }
}
