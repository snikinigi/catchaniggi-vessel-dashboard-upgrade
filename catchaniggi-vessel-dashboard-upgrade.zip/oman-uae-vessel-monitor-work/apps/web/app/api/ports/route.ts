import { NextResponse } from "next/server";
import { Pool } from "pg";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!process.env.DATABASE_URL) return NextResponse.json({ items: [], dataStatus: "not_connected" });
  const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 1 });
  try {
    const result = await pool.query(
      "SELECT id, locode, name, country_code AS \"countryCode\" FROM ports WHERE active = TRUE ORDER BY country_code, name"
    );
    return NextResponse.json({ items: result.rows, dataStatus: result.rows.length ? "ready" : "connected_no_results" });
  } catch {
    return NextResponse.json({ items: [], dataStatus: "provider_error" }, { status: 503 });
  } finally {
    await pool.end();
  }
}
