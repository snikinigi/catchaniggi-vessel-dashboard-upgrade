import type { AISProvider, NormalizedPortCall } from "./ais-provider";

type VFPortCall = {
  PORTCALL?: {
    ID?: string | number;
    MMSI?: string | number;
    IMO?: string | number;
    LOCODE?: string;
    EVENT?: string;
    TIMESTAMP?: string;
    PORT?: string;
    COUNTRY?: string;
  };
};

function parseProviderUtc(value: string): string {
  // Provider examples use "YYYY-MM-DD HH:mm:ss UTC".
  const normalized = value.replace(" UTC", "Z").replace(" ", "T");
  const date = new Date(normalized);
  if (Number.isNaN(date.getTime())) throw new Error(`Invalid provider timestamp: ${value}`);
  return date.toISOString();
}

export class VesselFinderProvider implements AISProvider {
  constructor(private readonly apiKey: string) {}

  async fetchPortCalls(input: { locode: string; fromUtc: Date; toUtcExclusive: Date }): Promise<NormalizedPortCall[]> {
    const url = new URL("https://api.vesselfinder.com/portcalls");
    url.searchParams.set("userkey", this.apiKey);
    url.searchParams.set("format", "json");
    url.searchParams.set("locode", input.locode);
    url.searchParams.set("fromdate", input.fromUtc.toISOString().slice(0, 19).replace("T", " "));
    url.searchParams.set("todate", new Date(input.toUtcExclusive.getTime() - 1000).toISOString().slice(0, 19).replace("T", " "));
    // Provider documentation marks interval as required; set it to the requested window in minutes.
    url.searchParams.set("interval", String(Math.ceil((input.toUtcExclusive.getTime() - input.fromUtc.getTime()) / 60000)));

    const controller = new AbortController();
    const timeout = Number(process.env.AIS_REQUEST_TIMEOUT_MS || 20000);
    const timer = setTimeout(() => controller.abort(), timeout);
    let response: Response;
    try {
      response = await fetch(url, { signal: controller.signal, cache: "no-store" });
    } finally {
      clearTimeout(timer);
    }
    if (!response.ok) throw new Error(`VesselFinder HTTP ${response.status}`);
    const payload: unknown = await response.json();
    if (!Array.isArray(payload)) throw new Error("Unexpected VesselFinder response: expected a JSON array");

    return (payload as VFPortCall[]).flatMap((row) => {
      const p = row.PORTCALL;
      if (!p || !p.LOCODE || !p.TIMESTAMP || !p.EVENT) return [];
      const event = p.EVENT.toLowerCase();
      if (event !== "arrival" && event !== "departure") return [];
      return [{
        providerEventId: p.ID == null ? null : String(p.ID),
        mmsi: p.MMSI == null ? null : String(p.MMSI),
        imo: p.IMO == null || String(p.IMO) === "0" ? null : String(p.IMO),
        locode: p.LOCODE,
        portName: p.PORT || p.LOCODE,
        country: p.COUNTRY || "",
        eventType: event,
        eventAt: parseProviderUtc(p.TIMESTAMP),
        raw: row
      }];
    });
  }
}
