export type NormalizedPortCall = {
  providerEventId: string | null;
  mmsi: string | null;
  imo: string | null;
  locode: string;
  portName: string;
  country: string;
  eventType: "arrival" | "departure";
  eventAt: string;
  raw: unknown;
};

export interface AISProvider {
  fetchPortCalls(input: {
    locode: string;
    fromUtc: Date;
    toUtcExclusive: Date;
  }): Promise<NormalizedPortCall[]>;
}
