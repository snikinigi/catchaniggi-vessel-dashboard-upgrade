import WebSocket from "ws";
import { Pool } from "pg";

type AISMessage = {
  error?: string;
  MessageType?: string;
  MetaData?: { MMSI?: string | number; latitude?: number; longitude?: number; time_utc?: string; timeUtc?: string; time?: string };
  Message?: { ShipStaticData?: { Name?: string; ImoNumber?: string | number; Type?: number; CallSign?: string; Dimension?: { A?: number; B?: number; C?: number; D?: number } }; PositionReport?: { Latitude?: number; Longitude?: number; Sog?: number; Cog?: number; TrueHeading?: number } };
};

const key = process.env.AISSTREAM_API_KEY;
const databaseUrl = process.env.DATABASE_URL;
if (!key) throw new Error("AISSTREAM_API_KEY is required; no live AIS connection was opened.");
if (!databaseUrl) throw new Error("DATABASE_URL is required.");

const pool = new Pool({ connectionString: databaseUrl, max: 4 });
const bounds = [[[15.0, 51.5], [27.5, 60.5]]]; // AISStream format: [latitude, longitude]

function vesselType(type: unknown): string | null {
  const n = Number(type);
  if (!Number.isFinite(n)) return null;
  if (n >= 60 && n < 70) return "Passenger";
  if (n >= 70 && n < 80) return "Cargo";
  if (n >= 80 && n < 90) return "Tanker";
  return null; // This monitor intentionally limits itself to commercial AIS classes.
}

function timestamp(meta: AISMessage["MetaData"], receivedAt: Date): { at: Date; source: string } {
  const raw = meta?.time_utc || meta?.timeUtc || meta?.time;
  if (raw) {
    const parsed = new Date(raw);
    if (!Number.isNaN(parsed.getTime())) return { at: parsed, source: "aisstream" };
  }
  // Provider timestamp was absent/unparseable: preserve the receive time and label it explicitly.
  return { at: receivedAt, source: "aisstream_received_at" };
}

async function findOrCreateVessel(input: { mmsi: string; imo?: string | null; name?: string | null; type?: string | null; length?: number | null; width?: number | null }) {
  const found = await pool.query("SELECT id FROM vessels WHERE mmsi=$1 OR ($2::text IS NOT NULL AND imo=$2) ORDER BY CASE WHEN mmsi=$1 THEN 0 ELSE 1 END LIMIT 1", [input.mmsi, input.imo || null]);
  if (found.rows[0]) {
    const updated = await pool.query(`UPDATE vessels SET
      mmsi=COALESCE(mmsi,$2), imo=COALESCE(NULLIF($3,''),imo), name=COALESCE(NULLIF($4,''),name),
      vessel_type=COALESCE(NULLIF($5,''),vessel_type), length_m=COALESCE($6,length_m), width_m=COALESCE($7,width_m),
      last_provider_sync_at=NOW() WHERE id=$1 RETURNING id`, [found.rows[0].id, input.mmsi, input.imo || "", input.name || "", input.type || "", input.length ?? null, input.width ?? null]);
    return updated.rows[0].id as string;
  }
  const inserted = await pool.query(`INSERT INTO vessels(mmsi,imo,name,vessel_type,length_m,width_m,last_provider_sync_at)
    VALUES($1,NULLIF($2,''),NULLIF($3,''),NULLIF($4,''),$5,$6,NOW()) RETURNING id`, [input.mmsi, input.imo || "", input.name || "", input.type || "", input.length ?? null, input.width ?? null]);
  return inserted.rows[0].id as string;
}

async function handle(message: AISMessage) {
  if (message.error) throw new Error(`AISStream error: ${message.error}`);
  const mmsi = String(message.MetaData?.MMSI || "").trim();
  if (!mmsi) return;
  const body = message.Message || {};
  const staticData = body.ShipStaticData;
  if (message.MessageType === "ShipStaticData" && staticData) {
    const type = vesselType(staticData.Type);
    if (!type) return;
    const dims = staticData.Dimension || {};
    await findOrCreateVessel({
      mmsi, imo: staticData.ImoNumber && String(staticData.ImoNumber) !== "0" ? String(staticData.ImoNumber) : null,
      name: (staticData.Name || "").trim(), type,
      length: Number(dims.A || 0) + Number(dims.B || 0) || null,
      width: Number(dims.C || 0) + Number(dims.D || 0) || null,
    });
    return;
  }

  const p = body.PositionReport;
  if (message.MessageType !== "PositionReport" || !p) return;
  const latitude = Number(p.Latitude ?? message.MetaData?.latitude);
  const longitude = Number(p.Longitude ?? message.MetaData?.longitude);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || Math.abs(latitude) > 90 || Math.abs(longitude) > 180) return;
  const existing = await pool.query("SELECT id FROM vessels WHERE mmsi=$1 AND vessel_type IS NOT NULL LIMIT 1", [mmsi]);
  if (!existing.rows[0]) return; // Ignore unknown/unclassified vessels until static data confirms a commercial class.
  const receivedAt = new Date();
  const observed = timestamp(message.MetaData, receivedAt);
  const vesselId = existing.rows[0].id as string;
  await pool.query(`INSERT INTO vessel_positions(vessel_id,observed_at,position,speed_knots,course_deg,heading_deg,source)
    VALUES($1,$2,ST_SetSRID(ST_MakePoint($3,$4),4326)::geography,$5,$6,$7,$8)
    ON CONFLICT(vessel_id,observed_at,source) DO NOTHING`, [vesselId, observed.at.toISOString(), longitude, latitude, p.Sog ?? null, p.Cog ?? null, p.TrueHeading ?? null, observed.source]);
  await pool.query("UPDATE vessels SET last_position_at=GREATEST(COALESCE(last_position_at,$2),$2), last_provider_sync_at=NOW() WHERE id=$1", [vesselId, observed.at.toISOString()]);
}

const socket = new WebSocket("wss://stream.aisstream.io/v0/stream");
let stopping = false;
const stop = async () => {
  if (stopping) return;
  stopping = true;
  socket.close();
  await pool.end();
  process.exit(0);
};
process.on("SIGINT", () => void stop());
process.on("SIGTERM", () => void stop());

socket.on("open", () => {
  console.log("AISStream connected; storing only real, classified commercial vessel positions.");
  socket.send(JSON.stringify({ APIKey: key, BoundingBoxes: bounds, FilterMessageTypes: ["PositionReport", "ShipStaticData"] }));
});
socket.on("message", (data) => {
  let message: AISMessage;
  try { message = JSON.parse(data.toString()) as AISMessage; }
  catch (error) { console.error("Ignoring invalid AIS message", error); return; }
  void handle(message).catch((error: unknown) => console.error("AIS message ingest failed:", error instanceof Error ? error.message : String(error)));
});
socket.on("error", (error) => { console.error("AISStream socket error:", error.message); });
socket.on("close", (code, reason) => {
  console.error(`AISStream disconnected (${code}): ${reason.toString()}`);
  void pool.end().finally(() => { process.exitCode = 1; });
});
