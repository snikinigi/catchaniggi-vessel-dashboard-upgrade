import { Pool } from "pg";
import { VesselFinderProvider } from "../providers/vesselfinder";

function parseCodes(value: string | undefined): string[] {
  return [...new Set((value || "").split(",").map((x) => x.trim().toUpperCase()).filter(Boolean))];
}

async function main() {
  const key = process.env.AIS_API_KEY;
  const databaseUrl = process.env.DATABASE_URL;
  if (!key) throw new Error("AIS_API_KEY is required; no AIS data was requested.");
  if (!databaseUrl) throw new Error("DATABASE_URL is required.");
  const ports = [...parseCodes(process.env.OMAN_PORT_LOCODES), ...parseCodes(process.env.UAE_PORT_LOCODES)];
  if (!ports.length) throw new Error("Configure verified OMAN_PORT_LOCODES and UAE_PORT_LOCODES first.");

  const days = Math.max(1, Math.min(90, Number(process.env.INGESTION_LOOKBACK_DAYS || 90)));
  const to = new Date();
  const from = new Date(to.getTime() - days * 86400000);
  const provider = new VesselFinderProvider(key);
  const pool = new Pool({ connectionString: databaseUrl, max: 3 });
  const run = await pool.query("INSERT INTO ingestion_runs(job_name) VALUES ($1) RETURNING id", ["sync-port-calls"]);
  const runId = run.rows[0].id;
  let received = 0;
  let inserted = 0;

  try {
    for (const locode of ports) {
      const events = await provider.fetchPortCalls({ locode, fromUtc: from, toUtcExclusive: to });
      received += events.length;

      for (const event of events) {
        const port = await pool.query(
          `SELECT id FROM ports WHERE locode=$1 LIMIT 1`, [event.locode]
        );
        if (!port.rowCount) {
          // Do not silently create ports from unverified provider text.
          console.warn(`Skipping event for unseeded/unknown port LOCODE ${event.locode}`);
          continue;
        }
        if (!event.imo && !event.mmsi) {
          console.warn(`Skipping event without a vessel identifier at ${event.locode}`);
          continue;
        }
        const existingVessel = await pool.query(
          `SELECT id FROM vessels WHERE ($1::text IS NOT NULL AND imo=$1) OR ($2::text IS NOT NULL AND mmsi=$2)
           ORDER BY CASE WHEN $1::text IS NOT NULL AND imo=$1 THEN 0 ELSE 1 END LIMIT 1`,
          [event.imo, event.mmsi]
        );
        let vesselId = existingVessel.rows[0]?.id as string | undefined;
        if (vesselId) {
          await pool.query(
            `UPDATE vessels SET imo=COALESCE(NULLIF($2,''),imo), mmsi=COALESCE(NULLIF($3,''),mmsi),
             last_provider_sync_at=NOW() WHERE id=$1`, [vesselId, event.imo || "", event.mmsi || ""]
          );
        } else {
          const created = await pool.query(
            `INSERT INTO vessels(imo,mmsi,last_provider_sync_at) VALUES(NULLIF($1,''),NULLIF($2,''),NOW()) RETURNING id`,
            [event.imo || "", event.mmsi || ""]
          );
          vesselId = created.rows[0]?.id as string | undefined;
        }
        if (!vesselId) continue;
        const result = await pool.query(
          `INSERT INTO port_calls(provider_event_id, vessel_id, port_id, event_type, event_at, source, raw_payload)
           VALUES ($1,$2,$3,$4,$5,'vesselfinder',$6::jsonb)
           ON CONFLICT (source, provider_event_id) WHERE provider_event_id IS NOT NULL DO NOTHING`,
          [event.providerEventId, vesselId, port.rows[0].id, event.eventType, event.eventAt, JSON.stringify(event.raw)]
        );
        inserted += result.rowCount || 0;
      }
      // Conservative sequential calls by default. Add provider-approved throttling if needed.
    }
    await pool.query(
      `UPDATE ingestion_runs SET finished_at=NOW(), status='success', records_received=$2, records_inserted=$3 WHERE id=$1`,
      [runId, received, inserted]
    );
    console.log(JSON.stringify({ status: "success", portsQueried: ports.length, received, inserted }));
  } catch (error) {
    await pool.query(
      `UPDATE ingestion_runs SET finished_at=NOW(), status='failed', records_received=$2, records_inserted=$3, error_message=$4 WHERE id=$1`,
      [runId, received, inserted, error instanceof Error ? error.message : String(error)]
    );
    throw error;
  } finally {
    await pool.end();
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
