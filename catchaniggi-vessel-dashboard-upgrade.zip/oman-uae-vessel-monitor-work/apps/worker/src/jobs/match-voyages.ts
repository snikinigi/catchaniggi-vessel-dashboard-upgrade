import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required.");
const pool = new Pool({ connectionString: databaseUrl, max: 2 });

async function main() {
  const run = await pool.query("INSERT INTO ingestion_runs(job_name) VALUES ($1) RETURNING id", ["match-port-call-voyages"]);
  const runId = run.rows[0].id as string;
  try {
    // Only pair a provider-observed Oman departure with a later UAE arrival for the same vessel/source.
    // No destination-text-only event is upgraded to confirmed. The earliest valid UAE arrival wins,
    // and an intervening Oman departure prevents an older departure from being paired incorrectly.
    const result = await pool.query(`
      WITH oman_departures AS (
        SELECT pc.id, pc.vessel_id, pc.port_id, pc.event_at, pc.source
        FROM port_calls pc JOIN ports p ON p.id=pc.port_id
        WHERE p.country_code='OM' AND pc.event_type='departure'
          AND pc.event_at >= NOW() - INTERVAL '90 days'
      ), uae_arrivals AS (
        SELECT pc.id, pc.vessel_id, pc.port_id, pc.event_at, pc.source
        FROM port_calls pc JOIN ports p ON p.id=pc.port_id
        WHERE p.country_code='AE' AND pc.event_type='arrival'
          AND pc.event_at >= NOW() - INTERVAL '90 days'
      ), pairs AS (
        SELECT d.id AS departure_call_id, a.id AS arrival_call_id, d.vessel_id,
          d.port_id AS departure_port_id, a.port_id AS arrival_port_id,
          d.event_at AS departure_at, a.event_at AS arrival_at, d.source
        FROM oman_departures d
        JOIN uae_arrivals a ON a.vessel_id=d.vessel_id AND a.source=d.source
          AND a.event_at > d.event_at AND a.event_at <= d.event_at + INTERVAL '30 days'
        WHERE NOT EXISTS (
          SELECT 1 FROM oman_departures d2
          WHERE d2.vessel_id=d.vessel_id AND d2.source=d.source
            AND d2.event_at>d.event_at AND d2.event_at<a.event_at
        )
        AND NOT EXISTS (
          SELECT 1 FROM uae_arrivals a2
          WHERE a2.vessel_id=a.vessel_id AND a2.source=a.source
            AND a2.event_at>d.event_at AND a2.event_at<a.event_at
        )
      )
      INSERT INTO voyages(vessel_id,departure_call_id,arrival_call_id,departure_port_id,arrival_port_id,
        departure_at,arrival_at,match_status,match_method,source)
      SELECT vessel_id,departure_call_id,arrival_call_id,departure_port_id,arrival_port_id,
        departure_at,arrival_at,'confirmed','paired_provider_port_calls',source
      FROM pairs
      ON CONFLICT DO NOTHING
      RETURNING id
    `);
    await pool.query(`UPDATE ingestion_runs SET finished_at=NOW(),status='success',records_received=$2,records_inserted=$2 WHERE id=$1`, [runId, result.rowCount || 0]);
    console.log(JSON.stringify({ status: "success", confirmedVoyagesInserted: result.rowCount || 0 }));
  } catch (error) {
    await pool.query(`UPDATE ingestion_runs SET finished_at=NOW(),status='failed',error_message=$2 WHERE id=$1`, [runId, error instanceof Error ? error.message : String(error)]);
    throw error;
  } finally { await pool.end(); }
}

main().catch((error) => { console.error(error instanceof Error ? error.message : error); process.exit(1); });
