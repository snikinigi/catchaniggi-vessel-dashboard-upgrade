# Original `catchaniggi` prototype

The original project remains at https://github.com/snikinigi/catchaniggi. This package is a separate full-stack upgrade scaffold and does not overwrite the original `collect.py`, `index.html`, or GitHub Pages workflow.

Keep the original deployed site until the replacement has been deployed and verified. The old site is static GitHub Pages; the new Next.js dashboard needs a server-capable host, PostgreSQL/PostGIS, and a persistent AIS ingestion worker.
