# Migration plan from `snikinigi/catchaniggi`

Repository: https://github.com/snikinigi/catchaniggi

## Keep the current prototype safe

1. Leave `main` and the current GitHub Pages deployment untouched while building the replacement.
2. Create a new branch in the original repository (for example `feature/fullstack-vessel-monitor`) or import this package into a separate repository.
3. Keep the original `collect.py`, `index.html`, `README.md`, and `.github/workflows/update.yml` available as the legacy prototype until the new app has passed verification.
4. Do not copy the old static Pages deployment workflow over the new app. GitHub Pages serves static files and cannot host the Next.js API routes or persistent database worker.

## Why the architecture changes

The current collector uses short AISStream listening windows and JSON state/cache, with completed voyages aged out after about two days. That is useful for a prototype but cannot supply a reliable searchable 90-day archive. The new schema stores historical port calls and voyage matches in PostgreSQL/PostGIS, while a persistent worker stores live position observations.

The old dashboard includes explicitly fictional demo ships and can fall back to browser-saved data. The new dashboard intentionally does not import those examples and never uses them as real records.

## Recommended migration order

1. Provision a Node-capable web host and PostgreSQL with PostGIS.
2. Obtain and verify the historical provider contract/API access and live feed terms.
3. Run the database migration and insert only verified port LOCODEs/coordinates.
4. Import a small historical sample from one Oman and one UAE port; inspect provider timestamps and identifiers.
5. Run the live worker and verify real messages arrive and appear with source timestamps.
6. Check route matching against source departure and arrival events; retain ambiguous cases as candidates.
7. Test the UI and APIs with empty database, provider outage, duplicate messages, and stale position cases.
8. Deploy the app privately or on a staging URL; only then decide whether to switch the public URL.
9. Keep the old Pages deployment as rollback until the new service has run reliably.

## Not yet complete

This package is a buildable implementation scaffold, not a production-certified AIS product. In particular, the historical adapter needs provider-contract verification and robust pagination, voyage matching needs a dedicated matching job, and the live worker needs operational monitoring/reconnect policy. No live positions are available until real provider credentials and infrastructure are configured.
