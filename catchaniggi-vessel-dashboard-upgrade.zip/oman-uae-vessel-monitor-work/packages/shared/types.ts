export type DataStatus =
  | "not_connected"
  | "connected_no_results"
  | "partial_data"
  | "ready"
  | "provider_error";

export type VoyageRow = {
  id: string;
  vesselName: string | null;
  imo: string | null;
  mmsi: string | null;
  departurePort: string;
  departureCountry: string;
  departureAt: string | null;
  arrivalPort: string;
  arrivalCountry: string;
  arrivalAt: string | null;
  matchStatus: "candidate" | "confirmed" | "incomplete" | "rejected";
};
