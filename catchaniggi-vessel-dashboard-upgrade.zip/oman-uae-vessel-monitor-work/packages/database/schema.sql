CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS ports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_port_id TEXT,
  locode TEXT,
  name TEXT NOT NULL,
  country_code CHAR(2) NOT NULL CHECK (country_code IN ('OM', 'AE')),
  location GEOGRAPHY(POINT, 4326),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (country_code, locode)
);

CREATE TABLE IF NOT EXISTS vessels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mmsi TEXT UNIQUE,
  imo TEXT UNIQUE,
  name TEXT,
  vessel_type TEXT,
  flag_code CHAR(2),
  length_m NUMERIC,
  width_m NUMERIC,
  last_position_at TIMESTAMPTZ,
  last_provider_sync_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS port_calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_event_id TEXT,
  vessel_id UUID NOT NULL REFERENCES vessels(id),
  port_id UUID NOT NULL REFERENCES ports(id),
  event_type TEXT NOT NULL CHECK (event_type IN ('arrival', 'departure')),
  event_at TIMESTAMPTZ NOT NULL,
  source TEXT NOT NULL,
  source_updated_at TIMESTAMPTZ,
  raw_payload JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS port_calls_source_event_unique
  ON port_calls(source, provider_event_id) WHERE provider_event_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS port_calls_event_at_idx ON port_calls(event_at DESC);
CREATE INDEX IF NOT EXISTS port_calls_port_event_idx ON port_calls(port_id, event_type, event_at DESC);

CREATE TABLE IF NOT EXISTS voyages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vessel_id UUID NOT NULL REFERENCES vessels(id),
  departure_call_id UUID REFERENCES port_calls(id),
  arrival_call_id UUID REFERENCES port_calls(id),
  departure_port_id UUID NOT NULL REFERENCES ports(id),
  arrival_port_id UUID NOT NULL REFERENCES ports(id),
  departure_at TIMESTAMPTZ,
  arrival_at TIMESTAMPTZ,
  match_status TEXT NOT NULL DEFAULT 'candidate'
    CHECK (match_status IN ('candidate', 'confirmed', 'incomplete', 'rejected')),
  match_method TEXT NOT NULL,
  source TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (arrival_at IS NULL OR departure_at IS NULL OR arrival_at > departure_at)
);
CREATE INDEX IF NOT EXISTS voyages_departure_idx ON voyages(departure_at DESC);
CREATE INDEX IF NOT EXISTS voyages_route_idx ON voyages(departure_port_id, arrival_port_id);
CREATE INDEX IF NOT EXISTS voyages_status_idx ON voyages(match_status);

CREATE TABLE IF NOT EXISTS vessel_positions (
  vessel_id UUID NOT NULL REFERENCES vessels(id),
  observed_at TIMESTAMPTZ NOT NULL,
  position GEOGRAPHY(POINT, 4326) NOT NULL,
  speed_knots NUMERIC,
  course_deg NUMERIC,
  heading_deg NUMERIC,
  source TEXT NOT NULL,
  PRIMARY KEY (vessel_id, observed_at, source)
);
CREATE INDEX IF NOT EXISTS vessel_positions_time_idx ON vessel_positions(observed_at DESC);
CREATE INDEX IF NOT EXISTS vessel_positions_geo_idx ON vessel_positions USING GIST(position);

CREATE TABLE IF NOT EXISTS ingestion_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_name TEXT NOT NULL,
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  finished_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'running'
    CHECK (status IN ('running', 'success', 'partial', 'failed')),
  records_received INTEGER NOT NULL DEFAULT 0,
  records_inserted INTEGER NOT NULL DEFAULT 0,
  error_message TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS voyages_port_call_pair_unique
  ON voyages(departure_call_id, arrival_call_id)
  WHERE departure_call_id IS NOT NULL AND arrival_call_id IS NOT NULL;
