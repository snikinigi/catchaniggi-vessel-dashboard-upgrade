import { readFile } from "node:fs/promises";
import { Pool } from "pg";
import path from "node:path";

async function main() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  try {
    const sql = await readFile(path.join(process.cwd(), "packages/database/schema.sql"), "utf8");
    await pool.query(sql);
    console.log("Database schema applied.");
  } finally {
    await pool.end();
  }
}
main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
